function Header() {
  return (
    <div className="grid h-12 items-center bg-purple-800 p-2">
      <h1 className="text-white">Movie Search App</h1>
    </div>
  );
}

export default Header;
