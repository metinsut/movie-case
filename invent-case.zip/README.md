Project prepared node version 16.5

Project development run:
npm run dev
or
yarn dev

For build
npm run build
yarn build
